## Following changes are made on raw datasets-
- Move States names from Row to column
- Updated null with zeros
- FU
ll form distrct/state names
- Standardize district/states
