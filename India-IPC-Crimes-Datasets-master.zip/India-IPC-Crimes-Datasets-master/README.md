# India IPC Crimes Datasets

<b>Data Source</b>- <a href="https://ncrb.gov.in/crime-in-india-table-addtional-table-and-chapter-contents?page=1">India National Crime Records Bureau</a>

